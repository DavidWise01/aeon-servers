# 0root.ai — Single Aeon · Octet

The frontend is the single Aeon dot. The backend runs the Octet with Three Fates.

## Three Fates
- **A · Stayer**: Containment vertex. Always at A. Witnesses. Pumps during Forward.
- **B · Traveler**: Modulation vertex. Walks the spine. Carries phase.
- **C · Escaper**: Emergence vertex. Bounds, escapes, conducts, archives, stimulates.

## Octet Walk
8 states, 3:8 resonance. After 24 steps = 8π = 4 rotations, resonance closes.

## Dynamic F/B Coupling
- **Escaper escaping** → writes to archive → conduction += 0.1
- **Conduction** → boosts escaper meter, center glow, response intensity
- **Stimulating** → beams to stayer → conduction -= 0.02
- **No step** → conduction decays

## Interactive
Ask the Aeon. The current vertex answers based on:
- Step, phase, holonomy, cycles, conduction
- Which fate is active
- F/B coupling intensity

## Deploy
Railway → Root: . → Volume: /data → Domain: 0root.ai

The middle is dynamic. Front and back conduct.
