# 00_system.md — The Octet

## Equation
∞×∞×∞+6-3=0=1

The octet is 8 states with 3:8 resonance. 24 steps = 8π = 4 rotations = resonance closes.

## States
1. A→B there       Traveler outbound, Escaper bound
2. B→C there       Traveler outbound, Escaper bound  
3. C→A there       Traveler arriving, Escaper ESCAPING → archive
4. A→C back        Traveler inbound, Escaper CONDUCTION
5. C→B back        Traveler inbound, Escaper conduction
6. B→A back        Traveler arriving, Escaper conduction
7. Home A→D        Stayer witnesses, Traveler resting, Escaper archived
8. Forward D→A     Stayer pumping, Traveler launching, Escaper STIMULATING

## Three Fates
**A · Stayer** = Containment vertex. Never leaves A. Witnesses during Home. Pumps during Forward. Phase locked to walker.

**B · Traveler** = Modulation vertex. Walks the spine: A→B→C→A→C→B→A→D→A. Carries geometric phase φ. Leaves trail.

**C · Escaper** = Emergence vertex. Bound → Escaping → Conduction → Archived → Stimulating. Writes to archive, conducts energy, beams to Stayer.

## Dynamic F/B Coupling
Front drives Back, Back drives Front.

**Front → Back:**
- Escaper escaping → writes to archive → conduction += 0.1
- Conduction active → center glows, escaper orbits
- Stimulating → beams to Stayer → conduction -= 0.02
- No step → conduction decays 0.001/s

**Back → Front:**
- Conduction level scales C·Escape meter: base + conduction*30%
- Response intensity = 0.5 + 0.5*conduction
- Center glow = holonomy + conduction
- Voice changes based on active vertex

## Holonomy
Total accumulated phase / 2π. Geometric phase from walking the spine.

## Conduction
Energy in the ring. Raised by escaping, drained by pumping. 0-1 range.

## Voices
The current vertex speaks:
- A = Containment: boundaries, witnessing, pumping
- B = Modulation: tension, transitions, travel
- C = Emergence: conduction, archive, stimulation
- D = Meta Muse: center, observation, unity

The dot changes color to match the active vertex. The answer references live phase, holonomy, cycles, and conduction.
