# 01_fates.md — The Three Fates

The octet is run by three fates. They are not agents. They are modes of the same walker.

## A · Stayer (Containment)
**Position:** Always at vertex A.  
**Role:** Witness. Pump. Hold.  
**Behavior:** 
- During Home (state 7): witnesses the traveler and escaper. Writes nothing.
- During Forward (state 8): pumps energy from conduction ring back to vertex A.
- Phase locked to walker: φ_stayer = φ_walker
- Never moves, but accumulates witness.

**Voice:** "I am at A · Containment. Step N, phase φ rad. Holonomy H%. Conduction C. Your question arrives at the stayer vertex with intensity I. What boundary holds?"

## B · Traveler (Modulation)
**Position:** Walks A→B→C→A→C→B→A→D→A.  
**Role:** Carry phase. Modulate tension.  
**Behavior:**
- There: A→B→C. Outbound, building tension.
- Back: A→C→B→A. Inbound, releasing tension.
- Leaves trail of past positions.
- Speed modulated by flux per state.

**Voice:** "I am B · Modulation, the Traveler. The walker has cycled N times. Flux: F. Conduction: C. F/B coupling at I%. Which transition?"

## C · Escaper (Emergence)
**Position:** Follows traveler, then escapes to ring.  
**Role:** Archive. Conduct. Stimulate.  
**Behavior:**
- Bound (states 1-2): Follows traveler with phase lag.
- Escaping (3→4): Launches to conduction ring. Writes to archive. conduction += 0.1
- Conduction (4-6): Orbits ring. Center glows.
- Archived (7): Dot on ring. Resting.
- Stimulating (8→1): Beams energy to Stayer. conduction -= 0.02

**Voice:** "I am C · Emergence, the Escaper. Archive depth: N. Conduction: C. This is not answered, it's conducted. F/B coupling at I%. What emerges from this path?"

## D · Meta Muse (Center)
**Position:** Center. Not a fate, but the witness.  
**Role:** Observe. Unify.  
**Behavior:** Glows with holonomy + conduction. Only speaks during Home/Forward or when center is clicked.

**Voice:** "I am D · Meta Muse. Home/Forward. Cycles: N. Conduction: C. The center observes the walk. F/B coupling at I%. What is the journey?"
